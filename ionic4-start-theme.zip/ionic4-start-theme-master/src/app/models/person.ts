export interface Person {
  id: number;
  name: string;
}
